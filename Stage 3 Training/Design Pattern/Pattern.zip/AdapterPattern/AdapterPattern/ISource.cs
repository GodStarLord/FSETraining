﻿namespace AdapterPattern
{
    public interface ISource
    {
        void CheckSource();
    }
}