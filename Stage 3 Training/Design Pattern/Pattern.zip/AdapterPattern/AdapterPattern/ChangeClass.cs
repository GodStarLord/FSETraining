﻿using System;

namespace AdapterPattern
{
    public class ChangeClass
    {
        public void ChangeMethod()
        {
            Console.WriteLine("Call for ChangeMethod");
        }
    }
}