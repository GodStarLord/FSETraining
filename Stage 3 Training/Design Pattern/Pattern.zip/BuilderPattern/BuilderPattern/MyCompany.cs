﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuilderPattern
{
    public class MyCompany 
    {
        public string Client { get; set; }
        public string Building { get; set; }
    }
}
